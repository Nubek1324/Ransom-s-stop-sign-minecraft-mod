package net.mcreator.ransomstopsign.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RansomsStopSignItem extends Item {
	public RansomsStopSignItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON));
	}
}