/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ransomstopsign.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.ransomstopsign.item.RansomsStopSignItem;
import net.mcreator.ransomstopsign.RansomStopSignMod;

public class RansomStopSignModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RansomStopSignMod.MODID);
	public static final DeferredItem<Item> RANSOMS_STOP_SIGN;
	static {
		RANSOMS_STOP_SIGN = REGISTRY.register("ransoms_stop_sign", RansomsStopSignItem::new);
	}
	// Start of user code block custom items
	// End of user code block custom items
}