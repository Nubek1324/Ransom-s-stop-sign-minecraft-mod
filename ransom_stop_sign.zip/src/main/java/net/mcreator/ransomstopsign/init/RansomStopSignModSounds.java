/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ransomstopsign.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.ransomstopsign.RansomStopSignMod;

public class RansomStopSignModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, RansomStopSignMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> RANSOM_SIGN_BONK = REGISTRY.register("ransom-sign-bonk", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("ransom_stop_sign", "ransom-sign-bonk")));
}